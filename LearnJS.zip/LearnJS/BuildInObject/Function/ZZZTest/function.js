const m = function (a, b, c) {
  const aaa = {
    a,
    b,
    c,
  };

  console.log(aaa);
};

exports.mmm = m;
