const { mmm } = require("./function.js");

mmm(1, "22", true);
