// String 的 toLowerCase() 方法将该字符串转换为小写形式。


const sentence = "The quick brown fox jumps over the lazy dog.";

console.log(sentence.toLowerCase());
// Expected output: "the quick brown fox jumps over the lazy dog."