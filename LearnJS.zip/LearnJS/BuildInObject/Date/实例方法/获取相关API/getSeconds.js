// getSeconds() 方法根据本地时间，返回一个指定的日期对象的秒数。

const moonLanding = new Date("July 20, 69 00:20:18");

console.log(moonLanding.getSeconds());
// Expected output: 18