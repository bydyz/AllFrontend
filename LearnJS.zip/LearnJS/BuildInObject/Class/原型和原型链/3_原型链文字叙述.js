/*
  问题1: 实例对象身上的 __proto__ 指向谁 ?
    => 指向所属构造函数的 prototype
    => p1 所属的构造函数是 Person
    => p1.__proto__ 指向 Person.prototype

  问题2: Person.prototype 的 __proto__ 指向谁 ?
    => Person.prototype 所属的构造函数是谁
    => 因为  .prototype 是一个对象数据类型(Object)
    => 在 JS 内所有的 Object 数据类型都是属于 Object 这个内置构造函数
    => Person.prototype 是属于 Object 这个内置构造函数的
    => Person.prototype 的 __proto__ 指向 Object.prototype

  问题3: Person 的 __proto__ 指向谁 ?
    => Person 是一个函数, 函数本身也是一个对象, 就会有 __proto__
    => 在 JS 内, 所有的函数都是属于内置构造函数 Function 的实例
    => Person.__proto__ 指向 Function.prototype

  问题4: Object.prototype 的 __proto__ 指向谁 ?
    => Object.prototype 是一个对象数据类型, 只要是对象, 都是数据 Object 这个内置构造函数的
    => 注意: Object.prototype 在 JS 内叫做 顶级原型 , 不再有 __proto__ 了
    => Object.prototype 的 __proto__ 指向 null

  问题5: Object 的 __proto__ 指向谁 ?
    => Object 是内一个内置构造函数, 同时也是一个函数, 同时也是一个对象
    => 在 JS 内, 所以的函数都是属于内置构造函数 Function 的实例
    => Object 也是 Function 的实例
    => Object.__proto__ 指向 Function.prototype

  问题6: Function.prototype 的 __proto__ 指向谁 ?
    => Function.prototype 也是一个对象数据类型
    => 只要是对象数据类型都是 Object 的实例
    => Function.prototype 的 __proto__ 指向 Object.prototype

  问题7: Function 的 __proto__ 指向谁 ?
    => Function 也是一个内置构造函数, 也是一个函数
    => 在 JS 内, 所有的函数都是属于内置构造函数 Function 的实例
    => Function 自己是自己的构造函数
    => Function 自己是自己的实例对象
    => Function 所属的构造函数的是 Function

  原型链
    + 用 __proto__ 串联起来的对象链状结构
    + 注意: 使用 __proto__
    + 每一个对象数据类型, 都有一个属于自己的原型链
    + 作用: 为了访问对象成员

  对象访问机制:
    + 当你需要访问对象的成员的时候
    + 首先在自己身上查找, 如果有直接使用
    + 如果没有, 会自动去 __proto__ 上查找
    + 如果还没有, 就再去 __proto__ 上查找
    + 直到 Object.prototype 都没有, 那么返回 undefined
*/