// toString() 方法返回一个字符串，表示指定的数组及其元素。

const array1 = [1, 2, "a", "1a"];

console.log(array1.toString());
// Expected output: "1,2,a,1a"