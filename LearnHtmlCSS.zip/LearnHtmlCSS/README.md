# npm create vite



## 选择器

###   * 是 通配选择器（Universal Selector）