<template>
  <div>
    <!-- alt图片未正常显示时的展示内容，title悬浮于图片上时的展示内容 -->
    <img src="./雏田.gif" alt="请尝试刷新页面" />
    <img src="./雏田.gif" title="这是美丽的雏田" />
    <img src="./雏田.gif" alt="请尝试刷新页面" title="这是美丽的雏田" />
    <img src=".\雏田.gif" width="200px" height="200px" />
    <img src=".\雏田.gif" width="200px" height="200px" />
    <img src=".\雏田.gif" height="200px" />
    <img src=".\雏田.gif" width="200px" />
  </div>
</template>

<script setup>
// 创建函数
const InitPage = async () => {};
// 写在此处 大致相当于 created 里调用
InitPage();
</script>

<style lang="less" scope></style>
