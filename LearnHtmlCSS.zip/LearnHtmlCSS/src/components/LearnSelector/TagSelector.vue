<template>
  <div>111111</div>

  <h1>666666</h1>

  <p>999999</p>
</template>

<style scoped>
div {
  background-color: rgb(109, 109, 83);
  color: red;
}

h1 {
  color: blue;
}
</style>
