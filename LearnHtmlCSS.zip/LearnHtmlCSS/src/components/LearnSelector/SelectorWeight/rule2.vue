<template>
  <div>
    <p class="cp" style="background-color: brown">11111111111111</p>
  </div>

  <p>222222222222</p>
</template>

<script setup></script>

<style scoped>
div .cp {
  background-color: wheat;
}

div p {
  background-color: orange;
}

p {
  background-color: green;
}

/* <!-- 选择权重：div .cp > div p >p  --> */
</style>
