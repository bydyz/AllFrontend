<template>
  <div class="cDiv" id="iDiv" style="background-color: pink">111111111111111111</div>
</template>

<script setup></script>

<style scoped>
#iDiv {
  background-color: rgb(176, 176, 238);
}

.cDiv {
  background-color: rgb(233, 171, 171);
}

div {
  background-color: rgb(235, 235, 188);
}

/* 内联样式 > id选择器权重 > class选择器权重 > 标签选择器 */
</style>
