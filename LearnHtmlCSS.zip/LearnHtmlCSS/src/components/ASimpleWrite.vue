<template>
  <div>
    <div></div>
    <div></div>
    <div></div>
    <!-- div*3    回车 -->

    <div>1111111</div>
    <!-- div{1111111}     回车 -->

    <div>11111111</div>
    <div>11111111</div>
    <div>11111111</div>
    <div>11111111</div>
    <!-- div{11111111}*4 -->
    <!-- only div , its for one line(仅仅是div的作用就是占一行) -->

    <h3>体育sports</h3>
    <h3>体育<span style="color: gray">sports</span></h3>
    <h3>体育<span style="color: red">sports</span></h3>
    <!-- 小方块不是空格，是自动生成的 -->

    div{111}*3
  </div>
</template>

<script setup></script>

<style lang="less" scope></style>
