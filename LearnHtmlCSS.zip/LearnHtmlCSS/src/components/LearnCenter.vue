<template>
  <div class="w-[600px] h-[300px] border-solid border-[1px] border-[#999] rounded-[4px]">
    <center>
      我要赚大钱
      <br />
      加油加油!!!!!!22299888777 come on baby
    </center>

    <center>
      <span>MOTHER FUCKER, LIFE SUCK </span>
    </center>
  </div>
</template>

<script setup></script>

<style scoped></style>
