<template>
  <table>
    <tr>
      <td>1</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <td>4</td>
      <td>5</td>
      <td>6</td>
    </tr>
    <tr>
      <td>7</td>
      <td>8</td>
      <td>9</td>
    </tr>
  </table>
</template>

<style scope lang="stylus">
table
  border-spacing 0
td
  width 50px
  height 50px
  line-height 50px
  text-align: center
  border: 1px solid #999
</style>
