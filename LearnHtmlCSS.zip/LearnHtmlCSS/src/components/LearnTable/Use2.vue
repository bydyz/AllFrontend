<template>
  <table>
    <tr>
      <td>1</td>
      <td colspan="2" rowspan="2">2</td>
    </tr>
    <tr>
      <td>4</td>
    </tr>
    <tr>
      <td colspan="3">8</td>
    </tr>
  </table>
</template>

<style scope lang="stylus">
table
  border-spacing 0
td
  width 50px
  height 50px
  line-height 50px
  text-align: center
  border: 1px solid #999
</style>
