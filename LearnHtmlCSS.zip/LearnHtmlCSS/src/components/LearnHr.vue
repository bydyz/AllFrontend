<template>
  <div>
    <h2>第一组</h2>
    <hr />
    <hr noshade />
    <hr noshade />
    <!-- 属性和属性值一样可以省略 -->
    <hr noshade="noshade" />

    <h2>第二组</h2>
    <hr color="green" />
    <hr color="yellow" />
    <hr color="red" />
    <hr color="blue" />

    <h2>第三组</h2>
    <hr color="green" width="300" />
    <hr color="green" width="170" />
    <hr color="green" width="170" align="left" />
    <hr color="green" width="170" align="right" />
    <!-- 默认align的属性值为center -->
  </div>
</template>

<script setup></script>

<style scope></style>
