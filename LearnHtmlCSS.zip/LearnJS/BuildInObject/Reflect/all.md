# Reflect 并非一个构造函数
  不能通过 new 运算符对其进行调用
  不能将 Reflect 对象作为一个函数来调用。

# Reflect 的所有属性和方法都是静态的（就像 Math 对象）。