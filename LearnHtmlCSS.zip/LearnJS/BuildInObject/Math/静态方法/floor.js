// Math.floor() 函数总是返回小于等于一个给定数字的最大整数。



Math.floor(-Infinity); // -Infinity
Math.floor(-45.95); // -46
Math.floor(-45.05); // -46
Math.floor(-0); // -0
Math.floor(0); // 0
Math.floor(4); //   4
Math.floor(45.05); //  45
Math.floor(45.95); //  45
Math.floor(Infinity); // Infinity