// Math.round() 函数返回一个数字四舍五入后最接近的整数。



x = Math.round(20.49); //20
x = Math.round(20.5); //21
x = Math.round(-20.5); //-20
x = Math.round(-20.51); //-21