// 影响原数组，
// 删除最后一个元素，返回值为被删除的元素
// 空数组不会报错，返回 undefined

const plants = ["broccoli", "cauliflower", "cabbage", "kale", "tomato"];

console.log(plants.pop());
// Expected output: "tomato"

console.log(plants);
// Expected output: Array ["broccoli", "cauliflower", "cabbage", "kale"]



let a = []
console.log(a.pop())
console.log(a)