var fun = function() {
  console.log('111')
}

var funChild = new fun()

console.log(funChild)   // fun {}