var fun = function f1(a,b){
	return a+b;
};

console.log(fun);//表示打印的是该函数对象，输出的内容是：
/**
* var fun = function f1(a,b){
* 	return a+b;
* };
*/

console.log(fun(1,2));//表示执行f1函数返回的结果是：3







// 4.return break continue
// return可以结束整个函数

// break可以退出当前的循环

// continue用于路过当次循环