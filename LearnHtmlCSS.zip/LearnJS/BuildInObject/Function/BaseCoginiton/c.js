// 3.函数返回值
// 可以使用return来设置函数的返回值

// 语法： ​ return 值;

// return后的值将会作为函数的执行结果返回，可以定义一个变量，来接收该结果

// 在函数return后的语句都不会执行

// 如果return语句后不跟任何就相当于返回一个undefined，如果函数中不写return，则也返回undefined

// return后可以跟任意类型的值