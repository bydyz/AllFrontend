// Set[Symbol.species] 静态访问器属性是一个未使用的访问器属性，指定了如何复制 Set 对象

// 目前所有 Set 方法均未使用此属性。