const mySet = new Set(['apple', 'banana', 'orange']);
// 使用展开运算符转换为数组
const myArray = [...mySet];
console.log(myArray);
// 输出: [ 'apple', 'banana', 'orange' ]