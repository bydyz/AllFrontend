// getUTCSeconds() 方法以世界时为标准，返回一个指定的日期对象的秒数。


const moonLanding = new Date("July 20, 1969, 20:18:04 UTC");

console.log(moonLanding.getUTCSeconds());
// Expected output: 4