// getMinutes() 方法根据本地时间，返回一个指定的日期对象的分钟数。

const birthday = new Date("March 13, 08 04:20");

console.log(birthday.getMinutes());
// Expected output: 20