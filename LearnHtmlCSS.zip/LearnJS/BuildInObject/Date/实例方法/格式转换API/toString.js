const dateItem = new Date("August 19, 1975 23:15:30");

console.log(dateItem.toString());
// Expected output: "Tue Aug 19 1975 23:15:30 GMT+0200 (CEST)"