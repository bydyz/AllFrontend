# 描述

创建一个 JavaScript Date 实例，该实例呈现时间中的某个时刻。
Date 对象则基于 Unix Time Stamp，即自 1970 年 1 月 1 日（UTC）起经过的毫秒数。