// BigInt(value)

// BigInt() 不与 new 运算符一起使用。


BigInt(123);
// 123n